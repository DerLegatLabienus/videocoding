var _             = require('underscore'),
    sprintf       = require('sprintf-js').sprintf,
    child_process = require('child_process'),

    db            = require('./dbschema'),
    directories   = require('./directories');

var without_extension = directories.without_extension;
var CodedModel = db.CodedModel;

var build_cmd = function(user, video, frames) {

    var flags = [ 'no-deblock', 'no-scenecut', 'no-mbtree', 'constrained-intra', 'no-interlaced' ]; 

    var default_params = {'profile'   : 'baseline',
        'input-res'   : sprintf('%dx%d', video.width, video.height),
        'slices'      : 1,
        'frames'      : frames,
        'ref'         : 1,
        'rc4-keyfile' : '../angexp/key_dec.bin'};

    var exec = './x264';
    var videos_dir = '../videos';

    var stringify_flags = function(flags) {
        return (_.map(flags, function(f) { return '--' + f; })).join(' ');
    }

    var stringify_params = function(params) {
        var foo = function(p) { return ['--', p[0], ' ', p[1]].join(''); };
        return (_.map(_.pairs(params), foo)).join(' ');
    }

    var remove_double_spaces = function(str) {
        return str.replace(/ +/g, " ");
    }

    var coded_path = sprintf("%s/coded/%s/%s.264", videos_dir, user, without_extension(video.name));
    var video_path = sprintf("%s/raw/%s", videos_dir, video.name);

    var params = _.extend(default_params, { 'output' : coded_path } );
    var cmd = [exec, stringify_flags(flags) , stringify_params(params), video_path ].join(' ');
    return remove_double_spaces(cmd);
};

exports.encode = function(user, video, frames, callback) {
    if (!frames) {
        frames = 100;
    }
    var cmd = build_cmd(user, video, frames);
    console.log('cmd', cmd);

    var enc = child_process.exec(cmd, function(error, stdout, stderr) {
        if (error) {
            console.log(error.stack);
            console.log('error code: ' + error.code);
            console.log('signal received: ' + error.signal);
        }
        if (stdout) {console.log('child process STDOUT: ' + stdout);}
        if (stderr) {console.log('child process STDERR: ' + stderr);}
    });

    enc.on('exit', function(code) {
        if (code == 0) {
            console.log('finished encoding successfully');
            callback();
        } else {
            console.log('encoder return code:', code);
        }
    });
}
