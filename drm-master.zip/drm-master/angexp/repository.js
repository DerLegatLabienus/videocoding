var _            = require('underscore'),
    mediainfo    = require('mediainfo'),
    fs           = require('fs'),
    dbschema     = require('./dbschema'),
    directories  = require('./directories'),
    childProcess = require('child_process');

var VideoModel = dbschema.VideoModel;
var without_extension = directories.without_extension;
var without_path       = directories.without_path;

exports.read_videos = function() {
    var dir = '../videos/raw';
    var files = fs.readdirSync(dir);
    for (var i = 0; i < files.length; i++) {
        mediainfo(dir + '/' + files[i], function(err, res) {
            if (err) {
                return console.log(err);
            }

            _.each(res, function(file) {
                var track = _.find(file.tracks, function(track) { return track.type === 'Video'; });
                var filename = without_path(file.complete_name);
                var video = new VideoModel({
                    name:  filename,
                    width : track.width.split(' ')[0],
                    height : track.height.split(' ')[0],
                    frames : 100,
                });
                var upsertData = video.toObject();
                delete upsertData._id;
                VideoModel.update({name: video.name}, upsertData, {upsert: true}, function(err) {
                    if (err) {
                        console.log(err);
                    }
                });
                var avconv = 'avconv -i ' + file.complete_name + ' -s 200x200 ' + __dirname + '/public/images/videos/' + without_extension(filename) + '.jpg';
                childProcess.exec(avconv, function(error, stdout, stderr) {
                    if (error != null) {
                        console.log('avconv error', error);
                    };
                });
            });
        });
    };
}


