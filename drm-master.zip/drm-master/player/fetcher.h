#ifndef _LISTENER_H_
#define _LISTENER_H_

int handle_block(int blk_size);
int setup_efds();

int run();

#endif
