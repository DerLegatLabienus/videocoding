#ifndef __LISTENER_H__
#define __LISTENER_H__

void* listener_thread(void* filename);
int setup_server();

#endif
