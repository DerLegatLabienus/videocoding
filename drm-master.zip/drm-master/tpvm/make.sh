#!/bin/bash
touch *
make clean && make
