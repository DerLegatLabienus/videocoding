#define KEYGEN 0x1
#define ENCRYPT 0x2
#define DECRYPT 0x3
#define GEN_ENCRYPTED_KEY 0x4
