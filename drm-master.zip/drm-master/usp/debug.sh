#!/bin/bash
cgdb --args playh264 ../streams/Aladin.264 --fps 0
