#!/bin/bash
./playh264 -k ../angexp/key_dec.bin ../encoder/Aladin.264 -f 49 --fps 0
