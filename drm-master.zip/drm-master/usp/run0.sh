#!/bin/bash
./playh264 ../streams/Aladin.264 --fps 0
